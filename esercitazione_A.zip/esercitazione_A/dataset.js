const dataset = `companyType,nCompanies,percControlled,evasion
small,5000000,0.03,8900000000
medium,56000,0.14,3600000000
big,5300,0.32,2400000000
`