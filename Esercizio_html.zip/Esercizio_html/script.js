function Stampa_lista(){
    var miaStringa = document.testo.value;
    document.getElementById("result").innerText = miaStringa;
}

function Resto(){
    var calcolo_resto = document.getElementById("investimento").innerHTML
    return calcolo_resto
}